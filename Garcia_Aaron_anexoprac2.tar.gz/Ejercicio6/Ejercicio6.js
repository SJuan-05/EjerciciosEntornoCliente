function calcularCadena(){
    let cadena = "2 + 2"
    let hacerEval = eval(cadena);
    alert("La cadena de 2 + 2 es igual a "  + hacerEval);
}