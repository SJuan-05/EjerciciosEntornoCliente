let hipervinculo = document.getElementById('hipervinculo');

function avisarHipervinculo() {

    alert("Estas encima de un hipervinculo!");

}

hipervinculo.addEventListener('mouseover', avisarHipervinculo);
