function cambiarColores(color){
    document.getElementById("contenedor").style.background = color;
  }
  