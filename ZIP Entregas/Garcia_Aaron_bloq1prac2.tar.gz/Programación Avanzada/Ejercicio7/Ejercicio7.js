function cambiarColor(color){

    document.body.style.background = color;

}

