let numero = parseInt(prompt("Introduce un numero y te diré si es para o impar"));

if (numero % 2 == 0){

    alert("Es numero par");

} else {

    alert("Es numero impar");

}