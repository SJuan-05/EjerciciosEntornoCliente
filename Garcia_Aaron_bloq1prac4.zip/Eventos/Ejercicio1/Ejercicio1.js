function tamañoTextoMas(tamaño){

    tamaño.style.fontSize = "16pt";

}

function tamañoTextoMenos(tamaño){

    tamaño.style.fontSize = "12pt";

}